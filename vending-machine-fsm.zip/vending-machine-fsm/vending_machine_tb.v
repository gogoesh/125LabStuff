`timescale 1ns/1ps
module vending_machine_tb;

    reg        clk, reset;
    reg        N, D, Q;
    wire       Dispense, ReturnNickel, ReturnDime, ReturnTwoDimes;
    reg  [3:0] expected;
    reg  [7:0] testvectors [0:199];
    integer    vectornum, errors;

    vending_machine dut (
        .clk(clk), .reset(reset), .N(N), .D(D), .Q(Q),
        .Dispense(Dispense), .ReturnNickel(ReturnNickel),
        .ReturnDime(ReturnDime), .ReturnTwoDimes(ReturnTwoDimes));

    always begin
        clk = 0; #5;
        clk = 1; #5;
    end

    initial begin
        $readmemb("test_vector.tv", testvectors);
        vectornum = 0;
        errors    = 0;
        {reset, N, D, Q, expected} = testvectors[0];
    end

    always @(posedge clk) begin
        #1;
        if ({Dispense, ReturnNickel, ReturnDime, ReturnTwoDimes} !== expected) begin
            $display("ERROR vector %0d: inputs reset=%b N=%b D=%b Q=%b",
                     vectornum, reset, N, D, Q);
            $display("      outputs = %b (expected %b)",
                     {Dispense, ReturnNickel, ReturnDime, ReturnTwoDimes}, expected);
            errors = errors + 1;
        end
        vectornum = vectornum + 1;
        if (testvectors[vectornum] === 8'bx) begin
            $display("%0d tests completed with %0d errors", vectornum, errors);
            $stop;
        end
        {reset, N, D, Q, expected} = testvectors[vectornum];
    end

endmodule
