module vending_machine_gates (input  clk,
                              input  reset,
                              input  N, D, Q,
                              output Dispense,
                              output ReturnNickel,
                              output ReturnDime,
                              output ReturnTwoDimes);

  reg  [3:0] S;
  wire [3:0] NS;

  wire E2 = ~S[3] & S[2];
  wire E1 = ~S[3] & S[1];
  wire E0 = ~S[3] & S[0];

  wire K = ~N & ~D;

  assign NS[3] = Q | (N & E2) | (D & E2) | (D & E1 & E0);
  assign NS[2] = (K & E2) | (N & E1 & E0) | (D & E1 & ~E0);
  assign NS[1] = (K & E1) | (N & (E1 ^ E0)) | (D & ~E1 & ~E2);
  assign NS[0] = (K & E0) | (N & ~E0 & ~E2) | (D & E0 & ~E1) | (D & E2);

  always @(posedge clk, posedge reset)
    if (reset) S <= 4'b0000;
    else       S <= NS;

  assign Dispense       = S[3];
  assign ReturnNickel   = S[3] & S[0];
  assign ReturnDime     = S[3] & S[1];
  assign ReturnTwoDimes = S[3] & S[2];
endmodule
