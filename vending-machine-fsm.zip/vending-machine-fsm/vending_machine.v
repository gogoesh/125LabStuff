module vending_machine (input  clk,
                        input  reset,
                        input  N, D, Q,
                        output Dispense,
                        output ReturnNickel,
                        output ReturnDime,
                        output ReturnTwoDimes);

  reg [3:0] state, nextstate;

  parameter S0  = 4'b0000;
  parameter S5  = 4'b0001;
  parameter S10 = 4'b0010;
  parameter S15 = 4'b0011;
  parameter S20 = 4'b0100;
  parameter S25 = 4'b1000;
  parameter S30 = 4'b1001;
  parameter S35 = 4'b1010;
  parameter S40 = 4'b1011;
  parameter S45 = 4'b1100;

  always @(posedge clk, posedge reset)
    if (reset) state <= S0;
    else       state <= nextstate;

  always @(*)
    case (state)
      S0, S25, S30, S35, S40, S45:
               if      (N) nextstate = S5;
               else if (D) nextstate = S10;
               else if (Q) nextstate = S25;
               else        nextstate = S0;
      S5:      if      (N) nextstate = S10;
               else if (D) nextstate = S15;
               else if (Q) nextstate = S30;
               else        nextstate = S5;
      S10:     if      (N) nextstate = S15;
               else if (D) nextstate = S20;
               else if (Q) nextstate = S35;
               else        nextstate = S10;
      S15:     if      (N) nextstate = S20;
               else if (D) nextstate = S25;
               else if (Q) nextstate = S40;
               else        nextstate = S15;
      S20:     if      (N) nextstate = S25;
               else if (D) nextstate = S30;
               else if (Q) nextstate = S45;
               else        nextstate = S20;
      default:             nextstate = S0;
    endcase

  assign Dispense       = (state == S25) | (state == S30) | (state == S35) |
                          (state == S40) | (state == S45);
  assign ReturnNickel   = (state == S30) | (state == S40);
  assign ReturnDime     = (state == S35) | (state == S40);
  assign ReturnTwoDimes = (state == S45);

endmodule
